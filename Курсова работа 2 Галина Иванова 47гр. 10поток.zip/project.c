#include<stdio.h>

#include<stdlib.h>

#include <time.h>

struct TerrainCell {
  int height;
  int type;
  int pp;
};

struct Point {
  int x;
  int y;

};

void MapTerrain(struct TerrainCell cell) {
  FILE * fptr;
  fptr = fopen("data.bin", "rb");

  for (int i = 0; i < 1513; i++) {

    fread( & cell, sizeof(struct TerrainCell), 1, fptr);

    if (cell.type == -1) {
      printf("\n");
    } else {
      printf("%d", cell.type);
    }
  }
  fclose(fptr);

}

void MapHeight(struct TerrainCell cell) {
  FILE * fptr;
  fptr = fopen("data.bin", "rb");

  for (int i = 0; i < 1513; i++) {
    fread( & cell, sizeof(struct TerrainCell), 1, fptr);

    if (cell.height == -1) {
      printf("\n");
    } else {
      if (cell.height > 10)
        printf("8", cell.height);

      if (cell.height == 10)
        printf("o", cell.height);

      if (cell.height < 10)
        printf(".", cell.height);
    }

  }
  fclose(fptr);

}

/*void PrintTracedMap(struct TerrainCell map[17][89]){
    int i;
    for(i=0; i<16;i++){
         for( int j=0; j<89;j++){

            //printf("%c",map[i][j].type == 5 ? ' ' : '0');
        }
        printf("\n");
    }
}*/

void Jumb(struct TerrainCell map[17][89], struct Point * jumb_trace) {
  int a = map[jumb_trace -> y][jumb_trace -> x].height;
  int h = 0;

  for (int i = 0; i < 3; i++) {
    if (h < (map[jumb_trace -> y][jumb_trace -> x].height)) {

      h = map[jumb_trace -> y][jumb_trace -> x].height;
    } else {
      printf("\n no jumbs  \n");
      return 0;
    }
    jumb_trace++;
  }
  int m = h;
  h -= a;
  double sum = h / 3;

  if (sum < 1.0) {

  } else {
    printf("\n no jumbs  \n");
    return 0;
  }

  for (int i = 0; i < 2; i++) {
    if (m > (map[jumb_trace -> y][jumb_trace -> x].height)) {
      m = map[jumb_trace -> y][jumb_trace -> x].height;
    } else {
      printf("\n no jumbs  \n");
      return 0;
    }
    jumb_trace++;

  }

  sum = h / 2;
  if (sum > 1.0) {
    jumb_trace -= 4;
    printf("\n Jumb - [%d][%d]\n", jumb_trace -> x, jumb_trace -> y);
  } else {
    printf("\n no jumbs  \n");
    return 0;
  }

}

void RoadTrace(struct TerrainCell map[17][89]) {

  int c = 0, m = 0;
  struct Point * p = (struct Point * ) malloc(20 * sizeof(struct Point));

  while (1) {

    scanf("%d", & (p -> x));
    scanf("%d", & (p -> y));

    if (map[p -> y][p -> x].type == 2 || map[p -> y][p -> x].type == 4) {
      printf("Error\n");
      RoadTrace(map);

    }

    c++;
    if (p -> x == (-1)) {

      break;
    }
    p++;

  }

  int n;
  p -= --c; //changes

  int s = 89, f = 0;
  int sy = 0, fy = 17;
  for (n = 0; n < c; n++) {

    if (s > p -> x) s = p -> x;
    if (f < p -> x) f = p -> x;

    if (sy < p -> y) sy = p -> x;
    if (fy > p -> y) fy = p -> x;

    p++; //changes
  }

  int sumx = f - s;
  int sumy = abs(fy - sy);

  struct Point * trace = (struct Point * ) malloc((sumx * sumy) * sizeof(struct Point));

  int j = 0;
  p -= c; //changes
  trace -> x = p -> x;
  trace -> y = p -> y;

  m++;

  for (int i = 1; i < c; i++) {

    ++p;
    int x, y;
    if (trace -> x <= p -> x) {
      x = trace -> x;
      y = trace -> y;
      while ((trace -> x) != (p -> x)) {
        trace++;
        trace -> x = ++x;

        trace--;
        if ((trace -> y > p -> y)) {
          trace++;
          trace -> y = --y;
        }
        if (trace -> y < p -> y) {

          trace++;
          trace -> y = ++y;
        }
        if (trace -> y == p -> y) {

          trace++;
          trace -> x = x;
          trace -> y = y;
        }

        m++;

        if (trace -> x == p -> x) {

          x = trace -> x;

          break;
        }

      }

      trace -> x = x;
      if (trace -> y > p -> y) {

        y = trace -> y;
        while ((trace -> y) != (p -> y)) {
          trace++;
          m++;

          trace -> x = x;
          trace -> y = --y;

          if (trace -> y == p -> y) break;

        }
      }

      if (trace -> y < p -> y) {

        int y = trace -> y;
        while ((trace -> y) != (p -> y)) {
          trace++;
          m++;

          trace -> x = x;
          trace -> y = ++y;

          if (trace -> y == p -> y) break;

        }
      }

    }

  }
  printf(" m = %d \n", m);
  int dessert = 0;
  struct Point * jumb_trace = (struct Point * ) malloc(5 * sizeof(struct Point));
  for (int t = m; t >= 0; t--) {
    if (1 == map[trace -> y][trace -> x].type) {
      dessert++;
      jumb_trace -> x = trace -> x;
      jumb_trace -> y = trace -> y;
      jumb_trace++;
    } else {

      jumb_trace -= dessert;
      dessert = 0;
    }
    if (dessert == 5) {
      jumb_trace -= 5;
      trace += 4;
      Jumb(map, jumb_trace);

    }
    printf("[%d,%d] \n", trace -> x, trace -> y);
    //map[trace->y][trace->x].type=5;
    trace--;
  }

  //PrintTracedMap(map);

  main();
  free(p);
  free(trace);

}

int main() {

  struct TerrainCell cell;
  struct TerrainCell map[17][89];

  int row = 17, col = 89;
  //struct TerrainCell *map = (struct TerrainCell *)malloc(row * col * sizeof(struct TerrainCell));

  FILE * fptr;

  fptr = fopen("data.bin", "rb");

  printf("17x89\n");

  int br = 0, i = 0, g = 0;

  for (int j; j < 1513; j++) {
    br += fread( & map[i][g], sizeof(struct TerrainCell), 1, fptr);
    if (89 == g) {
      i++;
      g = 0;
    } else {
      g++;
    }

  }

  /*
      for(i=0; i<16;i++){
       for( int j=0; j<89;j++){
          printf("%d",map[i][j].type );
      }
      printf("\n");
   }*/

  fclose(fptr);
  printf(" 1-for  MapTerrain\n");
  printf(" 2-for  MapHeight\n");
  printf(" 3-for  Road trace, (-1) for finish\n");

  printf("enter - end  \n");
  char c;

  while (c != '\n') {
    c = getchar();

    switch (c) {
    case '1':

      MapTerrain(cell);
      break;

    case '2':

      MapHeight(cell);
      break;

    case '3':
      printf("[x,y]\n");
      RoadTrace(map);
      break;

    }
    c = getchar();
  }

  return 0;
}
