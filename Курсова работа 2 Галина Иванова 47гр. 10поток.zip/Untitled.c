#include<stdio.h>

#include<stdlib.h>

#include <time.h>

struct TerrainCell {
  int height;
  int type;
  int pp;
};

int main() {
  srand(time(NULL)); // Initialization, should only be called once.

  struct TerrainCell cell;

  struct TerrainCell cell2;
  FILE * fptr;

  fptr = fopen("data.bin", "wb");

  srand(time(NULL)); // Initialization, should only be called once.
  int r = rand() % 50;
  char ch;

  FILE * t_filePointer = fopen("terrain.txt", "r");

  printf("17x89\n");
  int str = 0;

  for (int i = 0; i < 1513; i++) {

    ch = fgetc(t_filePointer);

    switch (ch) {
    case '0':
      cell.pp = r;

      cell.height = 10;
      cell.type = 0;
      str += fwrite( & cell, sizeof(struct TerrainCell), 1, fptr);
      break;

    case '1':
      cell.pp = r;

      cell.height = 20;
      cell.type = 1;
      str += fwrite( & cell, sizeof(struct TerrainCell), 1, fptr);
      break;

    case '2':
      cell.pp = r;

      cell.height = 0;
      cell.type = 2;
      str += fwrite( & cell, sizeof(struct TerrainCell), 1, fptr);
      break;

    case '3':
      cell.pp = r;

      cell.height = rand() % 10;
      cell.type = 3;
      str += fwrite( & cell, sizeof(struct TerrainCell), 1, fptr);
      break;
    case '4':
      cell.pp = r;

      cell.height = rand() % 10;
      cell.type = 4;
      str += fwrite( & cell, sizeof(struct TerrainCell), 1, fptr);
      break;

    default:
      cell.pp = -1;
      cell.height = -1;
      cell.type = -1;
      str += fwrite( & cell, sizeof(struct TerrainCell), 1, fptr);
      continue;
      break;

    }

    //printf(" %d %d %d ", cell.height, cell.type, cell.pp);
    //str=fwrite(&cell,sizeof(struct TerrainCell),1,fptr);
    //printf(" %d %d %d ",map[0][0].pp, map[0][0].height, map[0][0].type);

  }

  fclose(fptr);
  fptr = fopen("data.bin", "rb");

  for (int i = 0; i < 1513; i++) {
    fread( & cell2, sizeof(struct TerrainCell), 1, fptr);

    printf(" %d %d %d (%d) \n", cell2.height, cell2.type, cell2.pp, str);

  }

  fclose(t_filePointer);
  fclose(fptr);

  return 0;
}
